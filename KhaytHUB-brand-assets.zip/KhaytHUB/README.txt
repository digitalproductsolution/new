KhaytHUB brand assets

ILLUSTRATOR
Open any SVG in Adobe Illustrator. The emblem, outlined lettering and background are editable objects. Save as Adobe Illustrator (.ai) for a native working file. The outlined lettering requires no font installation.

LOGO SELECTION
Reference is a manual redraw of the supplied artwork. Refined uses the same wordmark with a cleaner oval. Start with horizontal for tight spaces, vertical for stacked placements, or emblem for square placements. The primary artboard includes generous background space.

SCREEN
Use SVG where supported. PNG exports are 512, 1024, 2048 and 4096 pixels wide. Transparent versions have names such as reverse, light, white and black. JPG uses the solid burgundy background. The 4096-pixel PNG and JPG files include an sRGB profile and 300 ppi metadata. The full emblem is available for app and social avatars. The simplified favicon is designed for small sizes.

PRINT
The print folder contains CMYK vector PDFs for all five layouts in both versions, in full colour on burgundy, burgundy on a light surface, or black. The regular SVG, EPS and PDF folders contain RGB artwork. Confirm the required press profile, bleed and trim with your printer before production. Place the logo at its intended size in the page layout.

BRAND GUIDE
The A4 guide covers palette, typography, spacing, minimum sizes and recommended backgrounds.
