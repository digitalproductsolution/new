KhaytHUB logo asset package

Open any SVG directly in Adobe Illustrator. The emblem, lettering and background are editable vector objects. To make a native Illustrator file, use File > Save As > Adobe Illustrator (.ai). Lettering is outlined and requires no font installation.

Reference is a manual vector redraw of the burgundy logo shown in chat. The visible lettering is haytHUB, with the preceding emblem serving as the K. Refined keeps the same lettering and layout and regularizes the oval and ornament stroke weights. Expect small differences from the reference image.

Each collection has five layouts and seven color treatments. Reverse uses cream and rose on transparency. Cream, white, black, burgundy and dark plum are available for different backgrounds. JPGs use the burgundy background. PNG sizes refer to canvas width in pixels.

SVG, PDF and EPS in the two collections use RGB artwork. The print folder includes a CMYK primary vector PDF. Ask your printer for their target profile when preparing a production run.
